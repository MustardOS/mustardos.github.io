#!/bin/sh

. /opt/muos/script/var/func.sh

SET_VAR "device" "board/network" "1"
SET_VAR "device" "board/portmaster" "1"

SET_VAR "device" "network/module" "/lib/modules/4.9.170/kernel/drivers/net/wireless/realtek/rtlwifi/rtl8188eu/8188eu.ko"
SET_VAR "device" "network/name" "8188eu"

# Update module dependencies
depmod

# Generate SSH Keys
/opt/openssh/bin/ssh-keygen -A