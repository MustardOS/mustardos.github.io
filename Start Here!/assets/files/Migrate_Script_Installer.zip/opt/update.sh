#!/bin/sh

# See if rsync exists and if not copy it to /usr/bin
if ! command -v rsync >/dev/null 2>&1; then
  cp /opt/rsync-aarch64 /usr/bin/rsync
  chmod +x /usr/bin/rsync
fi
